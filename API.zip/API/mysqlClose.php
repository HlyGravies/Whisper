<!-- 
    製作者：QUAN 
-->
<?php
function disconnect_db($pdo)
{
    $pdo = null;
}
?>